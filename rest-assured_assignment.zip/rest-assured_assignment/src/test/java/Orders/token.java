package Orders;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

public class token{

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void getBearerToken() {
        // Define the request payload
        String requestBody = "{\"clientName\": \"Postman Assignment 2\", \"clientEmail\": \"abc.example@example.com\"}";

        // Make POST request to get bearer token
        Response response = given()
                .baseUri(baseURL)
                .contentType(ContentType.JSON) // Specify content type as JSON
                .body(requestBody) // Set the request body
                .when()
                .post("/api-clients") // Use the endpoint
                .then()
                .log().all() // Log response details
                .statusCode(200) // Assuming 200 is the status code for successful token generation
                .extract().response();

        // Get the bearer/access token from the response
        String accessToken = response.jsonPath().getString("accessToken");

        // Assert that the bearer/access token is not null
        Assert.assertNotNull(accessToken, "Bearer/Access Token is null");

        // Print the bearer/access token
        System.out.println("Bearer/Access Token: " + accessToken);
    }
}

package Orders;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

public class create_new_order {

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();
    public String bearerToken = "<Replace_with_bearer_token>"; // Replace with the actual bearer token

    @Test
    public void createOrder() {
        // Define the request body
        String requestBody = "{\"cartId\": \"ZFe4yhG5qNhmuNyrbLWa4\", \"customerName\": \"John Doe\"}";

        // Make POST request to create an order
        Response response = given()
                .baseUri(baseURL)
                .header("Authorization", "Bearer " + bearerToken) // Set the Authorization header with bearer token
                .contentType(ContentType.JSON) // Specify content type as JSON
                .body(requestBody) // Set the request body
                .when()
                .post("/orders") // Use the endpoint
                .then()
                .log().all() // Log response details
                .statusCode(200) // Assuming 200 is the status code for successful creation of the order
                .extract().response();
        

        // Printing the response body
        System.out.println("Response Body: " + response.getBody().asString());
    }
}

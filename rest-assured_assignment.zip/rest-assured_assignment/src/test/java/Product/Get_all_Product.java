package Product;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class Get_all_Product {

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void product() {
        Response response = given().baseUri(baseURL)
                .when()
                .get("products")
                .then()
                .statusCode(200)
                .body("size()", greaterThan(0))
                .extract().response();
        System.out.println("statusCode: "+response.statusCode());
        System.out.println("Response Body: " + response.getBody().asString());
    }
}


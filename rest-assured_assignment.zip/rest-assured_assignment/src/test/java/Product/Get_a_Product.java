package Product;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

public class Get_a_Product{

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void getProductDetails() {
        // Define the product ID
        String productId = "1225"; // Replace "1225" with the actual product ID

        Response response = given()
                .baseUri(baseURL)
                .pathParam("productid", productId) // Set the path parameter for product ID
                .when()
                .get("/products/{productid}") // Use the path parameter in the URL
                .then()
                .statusCode(200)
                .extract().response();

        // Assertion for the status code
        int statusCode = response.statusCode();
        Assert.assertEquals(statusCode, 200, "Unexpected status code: " + statusCode);

        // Printing the response body
        System.out.println("Response Body: " + response.getBody().asString());
    }
}

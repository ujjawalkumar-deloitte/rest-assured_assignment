package Status;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

public class StatusAPI {
    String baseUrl = "https://simple-grocery-store-api.glitch.me/";

    @Test
    public void status() {
        Response response = given().baseUri(baseUrl)
                .when()
                .get("status")
                .then()
                .statusCode(200)
                .extract().response();

        System.out.println("Response Body: " + response.getBody().asString());
        System.out.println("statusCode: "+response.statusCode());
}
    }


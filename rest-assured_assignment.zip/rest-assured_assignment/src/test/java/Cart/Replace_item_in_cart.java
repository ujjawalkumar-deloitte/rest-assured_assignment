package Cart;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

public class Replace_item_in_cart {

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void replaceItemInCart() {
        // Define the cart ID
        String cartId = "LG1HX6p54JqWFX4ozW2SD"; // Replace "123" with the actual cart ID

        // Define the item ID
        String itemId = "755361755"; // Replace "456" with the actual item ID

        // Define the request payload for replacing the item
        String requestBody = "{\"productId\": \"3674\"}"; // Request payload to replace the item

        // Make PUT request to replace the item in the cart
        Response response = given()
                .baseUri(baseURL)
                .pathParam("cartId", cartId) // Set the path parameter for cart ID
                .pathParam("itemId", itemId) // Set the path parameter for item ID
                .contentType(ContentType.JSON) // Specify content type as JSON
                .body(requestBody) // Set the request body
                .when()
                .put("/carts/{cartId}/items/{itemId}") // Use the path parameters in the URL
                .then()
                .log().all() // Log response details
                .statusCode(200) // Assuming 200 is the status code for successful replacement of the item
                .extract().response();

        // Assert that the response indicates successful replacement of the item
        // Add more assertions if needed

        // Printing the response body
        System.out.println("Response Body: " + response.getBody().asString());
    }
}

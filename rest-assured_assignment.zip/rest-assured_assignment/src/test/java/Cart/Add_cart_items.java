package Cart;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

public class Add_cart_items {

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void addItemsToCart() {
        // Define the cart ID
        String cartId = "52kSryjyECyonYDJwKyQG"; //

        // Define the request payload for adding items to the cart
        String requestBody = "{\"productId\": \"1234\"}"; //

        // Make POST request to add items to the cart
        Response response = given()
                .baseUri(baseURL)
                .pathParam("cartId", cartId) //
                .contentType(ContentType.JSON) // Specify content type as JSON
                .body(requestBody) // Set the request body
                .when()
                .post("carts/{cartId}/items") // Use the path parameter in the URL
                .then()
                .statusCode(201) // Assuming 200 is the status code for successful addition of items
                .extract().response();

        // Printing the response body
        System.out.println("Response Body: " + response.getBody().asString());
    }
}

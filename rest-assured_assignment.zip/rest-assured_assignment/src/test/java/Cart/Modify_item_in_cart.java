package Cart;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

public class Modify_item_in_cart {

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void modifyItemInCart() {
        // Define the cart ID
        String cartId = "LG1HX6p54JqWFX4ozW2SD";
        // Define the item ID
        String itemId = "755361755";

        // Define the request payload for modifying the item
        String requestBody = "{\"quantity\": 1}"; // Request payload to modify the quantity

        // Make PATCH request to modify the item in the cart
        Response response = given()
                .baseUri(baseURL)
                .pathParam("cartId", cartId) // Set the path parameter for cart ID
                .pathParam("itemId", itemId) // Set the path parameter for item ID
                .contentType(ContentType.JSON) // Specify content type as JSON
                .body(requestBody) // Set the request body
                .when()
                .patch("/carts/{cartId}/items/{itemId}") // Use the path parameters in the URL
                .then()
                .log().all() // Log response details
                .statusCode(200) // Assuming 200 is the status code for successful modification of the item
                .extract().response();



        // Printing the response body
        System.out.println("Response Body: " + response.getBody().asString());
    }
}

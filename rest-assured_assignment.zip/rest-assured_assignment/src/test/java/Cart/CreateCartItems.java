package Cart;
import io.restassured.response.Response;
import org.testng.annotations.Test;
import utilities.ReadConfig;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;
import org.testng.Assert;

import java.util.HashMap;
import java.util.Map;

public class CreateCartItems {

    ReadConfig readConfig = new ReadConfig();
    public String baseURL = readConfig.getApplicationURL();

    @Test
    public void createNewCart() {


        Response response = given()
                .baseUri(baseURL)
                .when()
                .post("/carts") // Send POST request to /carts endpoint
                .then()
                .statusCode(201) // Expecting status code 201 for successful creation
                .extract().response();

        // Assertion for the status code
        int statusCode = response.statusCode();
        Assert.assertEquals(statusCode, 201, "Unexpected status code: " + statusCode);

        String cartId = response.jsonPath().getString("cartid");
        // Printing the response body
        System.out.println("Response Body: " + response.getBody().asString());
    }
}
